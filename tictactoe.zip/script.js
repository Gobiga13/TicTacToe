const cells = document.querySelectorAll('.cell');
const statusText = document.getElementById('status');
const popup = document.getElementById('popup');
const popupMessage = document.getElementById('popupMessage');
const scoreX = document.getElementById('scoreX');
const scoreO = document.getElementById('scoreO');

let currentPlayer = "X";
let board = ["", "", "", "", "", "", "", "", ""];
let gameActive = true;
let xScore = 0;
let oScore = 0;

const winPatterns = [
    [0,1,2],[3,4,5],[6,7,8],
    [0,3,6],[1,4,7],[2,5,8],
    [0,4,8],[2,4,6]
];

cells.forEach(cell => {
    cell.addEventListener('click', handleClick);
});

function handleClick(e) {
    const index = e.target.dataset.index;

    if (board[index] !== "" || !gameActive) return;

    board[index] = currentPlayer;
    e.target.textContent = currentPlayer;

    checkWinner();
}

function checkWinner() {
    for (let pattern of winPatterns) {
        const [a,b,c] = pattern;

        if (board[a] && board[a] === board[b] && board[a] === board[c]) {
            updateScore();
            showPopup(`Player ${currentPlayer} Wins! 🎉`);
            gameActive = false;
            return;
        }
    }

    if (!board.includes("")) {
        showPopup("It's a Draw!");
        gameActive = false;
        return;
    }

    currentPlayer = currentPlayer === "X" ? "O" : "X";
    statusText.textContent = `Player ${currentPlayer}'s Turn`;
}

function updateScore() {
    if (currentPlayer === "X") {
        xScore++;
        scoreX.textContent = xScore;
    } else {
        oScore++;
        scoreO.textContent = oScore;
    }
}

function restartGame() {
    board = ["", "", "", "", "", "", "", "", ""];
    cells.forEach(cell => cell.textContent = "");
    currentPlayer = "X";
    gameActive = true;
    statusText.textContent = "Player X's Turn";
}

function showPopup(message) {
    popupMessage.textContent = message;
    popup.style.display = "flex";
}

function closePopup() {
    popup.style.display = "none";
    restartGame();
}